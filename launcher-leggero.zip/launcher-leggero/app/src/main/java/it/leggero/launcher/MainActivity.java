package it.leggero.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Launcher minimale per Android TV: nessuna libreria e nessun servizio in background.
 * L'unico accesso alla rete e' il meteo (Open-Meteo, senza chiave ne' account),
 * aggiornato al massimo ogni 30 minuti e solo mentre la Home e' aperta.
 *
 * Telecomando:
 *   OK                     avvia l'app
 *   OK tenuto premuto      menu dell'app (preferiti, sposta, nascondi, informazioni)
 *   MENU / INFO / tasto *  stesso menu dell'app (oppure Impostazioni se il cursore e' sul pulsante)
 *   Indietro               ignorato (siamo la schermata Home)
 */
public class MainActivity extends Activity {

    // Tre livelli di dimensione: piccole, medie, grandi
    private static final int[] ICON_DP = {56, 72, 96};
    private static final int[] COL_DP = {140, 170, 220};
    private static final int[] CELL_DP = {108, 128, 162};
    private static final int[] TEXT_SP = {13, 15, 18};
    private static final String[] ICON_NAMES = {"Piccole", "Medie", "Grandi"};

    private static final int[] BG_COLORS = {
            0xFF000000, 0xFF1C1C1E, 0xFF0B1B33, 0xFF0F2A1D, 0xFF221538};
    private static final String[] BG_NAMES = {
            "Nero", "Antracite", "Blu notte", "Verde bosco", "Viola"};

    private static final String KEY_FAV = "fav";
    private static final String KEY_HIDDEN = "hidden";
    private static final String KEY_ORDER = "order";
    private static final String KEY_ICON = "icon";
    private static final String KEY_BG = "bg";
    private static final String KEY_CITY = "city";
    private static final String KEY_LAT = "lat";
    private static final String KEY_LON = "lon";
    private static final String KEY_W_TEMP = "w_temp";
    private static final String KEY_W_CODE = "w_code";
    private static final String KEY_W_MIN = "w_min";
    private static final String KEY_W_MAX = "w_max";
    private static final String KEY_W_TIME = "w_time";

    private static final long WEATHER_MAX_AGE = 30L * 60 * 1000;  // aggiorna dopo 30 minuti
    private static final long WEATHER_RETRY = 5L * 60 * 1000;     // dopo un errore riprova dopo 5 minuti
    private static final long WEATHER_STALE = 3L * 60 * 60 * 1000; // oltre 3 ore: "non aggiornato"

    private static final class AppEntry {
        final String label;
        final String pkg;
        final Intent launch;
        final ResolveInfo info;
        Drawable icon;     // per la griglia
        Drawable favIcon;  // per la riga dei preferiti (istanza separata)

        AppEntry(String label, String pkg, Intent launch, ResolveInfo info) {
            this.label = label;
            this.pkg = pkg;
            this.launch = launch;
            this.info = info;
        }
    }

    private final List<AppEntry> all = new ArrayList<>();       // tutte le app, in ordine alfabetico
    private final List<AppEntry> gridApps = new ArrayList<>();  // app visibili nella griglia
    private final List<AppEntry> favApps = new ArrayList<>();   // preferite visibili
    private final Handler ui = new Handler(Looper.getMainLooper());

    private PackageManager pm;
    private SharedPreferences prefs;
    private LinearLayout root;
    private TextView clock;
    private TextView date;
    private TextView hint;
    private TextView settingsBtn;
    private LinearLayout weatherBox;
    private TextView wTemp;
    private TextView wInfo;
    private boolean weatherLoading;
    private long lastWeatherTry;
    private HorizontalScrollView favScroll;
    private LinearLayout favRow;
    private GridView grid;
    private AppAdapter adapter;
    private int iconLevel;
    private int bgIndex;
    private int iconSize;
    private boolean loading;
    private boolean reloadPending;
    private boolean timeReceiverOn;

    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            reload();
        }
    };

    private final BroadcastReceiver timeReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateClock();
            refreshWeather(false); // si aggiorna solo se sono passati 30 minuti
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pm = getPackageManager();
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        iconLevel = clamp(prefs.getInt(KEY_ICON, 1), 0, ICON_DP.length - 1);
        bgIndex = clamp(prefs.getInt(KEY_BG, 0), 0, BG_COLORS.length - 1);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG_COLORS[bgIndex]);

        // Intestazione: ora e data a sinistra, pulsante Impostazioni a destra
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(48), dp(24), dp(48), dp(8));

        LinearLayout timeBox = new LinearLayout(this);
        timeBox.setOrientation(LinearLayout.VERTICAL);
        clock = new TextView(this);
        clock.setTextColor(Color.WHITE);
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 40);
        date = new TextView(this);
        date.setTextColor(0xFFB0B0B0);
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        timeBox.addView(clock);
        timeBox.addView(date);
        header.addView(timeBox, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        weatherBox = new LinearLayout(this);
        weatherBox.setOrientation(LinearLayout.VERTICAL);
        weatherBox.setPadding(dp(16), dp(6), dp(16), dp(6));
        weatherBox.setFocusable(true);
        weatherBox.setClickable(true);
        weatherBox.setBackground(focusBg());
        wTemp = new TextView(this);
        wTemp.setTextColor(Color.WHITE);
        wTemp.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28);
        wInfo = new TextView(this);
        wInfo.setTextColor(0xFFB0B0B0);
        wInfo.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        weatherBox.addView(wTemp);
        weatherBox.addView(wInfo);
        weatherBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCityDialog();
            }
        });
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wlp.setMargins(0, 0, dp(16), 0);
        header.addView(weatherBox, wlp);

        settingsBtn = new TextView(this);
        settingsBtn.setText("Impostazioni");
        settingsBtn.setTextColor(Color.WHITE);
        settingsBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        settingsBtn.setPadding(dp(16), dp(10), dp(16), dp(10));
        settingsBtn.setFocusable(true);
        settingsBtn.setClickable(true);
        settingsBtn.setBackground(focusBg());
        settingsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        header.addView(settingsBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Riga dei preferiti
        favRow = new LinearLayout(this);
        favRow.setOrientation(LinearLayout.HORIZONTAL);
        favScroll = new HorizontalScrollView(this);
        favScroll.setHorizontalScrollBarEnabled(false);
        favScroll.setPadding(dp(44), 0, dp(44), 0);
        favScroll.setClipToPadding(false);
        favScroll.addView(favRow);
        root.addView(favScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        hint = new TextView(this);
        hint.setText("Tieni premuto OK su un'app per aggiungerla ai preferiti");
        hint.setTextColor(0xFF8E8E93);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        hint.setPadding(dp(48), dp(4), dp(48), dp(4));
        root.addView(hint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Griglia di tutte le app
        grid = new GridView(this);
        grid.setNumColumns(GridView.AUTO_FIT);
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(8));
        grid.setPadding(dp(48), dp(8), dp(48), dp(32)); // margini di overscan
        grid.setClipToPadding(false);
        grid.setSelector(new ColorDrawable(0x55FFFFFF));
        grid.setSmoothScrollbarEnabled(false);
        grid.setVerticalScrollBarEnabled(false);

        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                launch(gridApps.get(position));
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                showAppMenu(gridApps.get(position), false);
                return true;
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        applySize();
        grid.requestFocus();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(packageReceiver, f);

        reload();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateClock();
        showWeather();
        refreshWeather(false);
        if (!timeReceiverOn) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_TIME_TICK); // una volta al minuto, solo a schermo acceso
            f.addAction(Intent.ACTION_TIME_CHANGED);
            f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
            registerReceiver(timeReceiver, f);
            timeReceiverOn = true;
        }
    }

    @Override
    protected void onPause() {
        if (timeReceiverOn) {
            unregisterReceiver(timeReceiver);
            timeReceiverOn = false;
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        unregisterReceiver(packageReceiver);
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home premuto mentre siamo gia' aperti: torna in cima alla griglia
        if (grid != null && gridApps.size() > 0) {
            grid.setSelection(0);
            grid.requestFocus();
        }
    }

    @Override
    public void onBackPressed() {
        // Un launcher non deve chiudersi con Indietro
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU
                || keyCode == KeyEvent.KEYCODE_INFO
                || keyCode == KeyEvent.KEYCODE_STAR) {
            View f = getCurrentFocus();
            if (f == grid) {
                int pos = grid.getSelectedItemPosition();
                if (pos >= 0 && pos < gridApps.size()) {
                    showAppMenu(gridApps.get(pos), false);
                    return true;
                }
            } else if (f != null && f.getTag() instanceof AppEntry) {
                showAppMenu((AppEntry) f.getTag(), true);
                return true;
            }
            showSettings();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ---------------------------------------------------------------- ora e data

    private void updateClock() {
        Date now = new Date();
        String pattern = DateFormat.is24HourFormat(this) ? "HH:mm" : "h:mm a";
        clock.setText(new SimpleDateFormat(pattern, Locale.getDefault()).format(now));
        String d = new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now);
        if (d.length() > 0) {
            d = Character.toUpperCase(d.charAt(0)) + d.substring(1);
        }
        date.setText(d);
    }

    // ---------------------------------------------------------------- dati salvati

    private List<String> getList(String key) {
        List<String> out = new ArrayList<>();
        String s = prefs.getString(key, "");
        if (s.length() > 0) {
            for (String p : s.split(",")) {
                if (p.length() > 0) out.add(p);
            }
        }
        return out;
    }

    private void putList(String key, List<String> list) {
        prefs.edit().putString(key, TextUtils.join(",", list)).apply();
    }

    private AppEntry find(String pkg) {
        for (AppEntry e : all) {
            if (e.pkg.equals(pkg)) return e;
        }
        return null;
    }

    /** Ricalcola griglia e preferiti da elenco app, nascoste, ordine e preferite. */
    private void rebuildLists() {
        Set<String> hidden = new HashSet<>(getList(KEY_HIDDEN));
        final List<String> order = getList(KEY_ORDER);

        gridApps.clear();
        for (AppEntry e : all) {
            if (!hidden.contains(e.pkg)) gridApps.add(e);
        }
        Collections.sort(gridApps, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                int ia = order.indexOf(a.pkg);
                int ib = order.indexOf(b.pkg);
                if (ia < 0) ia = Integer.MAX_VALUE;
                if (ib < 0) ib = Integer.MAX_VALUE;
                if (ia != ib) return ia < ib ? -1 : 1;
                return String.CASE_INSENSITIVE_ORDER.compare(a.label, b.label);
            }
        });

        favApps.clear();
        for (String p : getList(KEY_FAV)) {
            AppEntry e = find(p);
            if (e != null && !hidden.contains(p)) favApps.add(e);
        }

        adapter.notifyDataSetChanged();
        buildFavRow();
    }

    // ---------------------------------------------------------------- aspetto

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private Drawable focusBg() {
        StateListDrawable d = new StateListDrawable();
        d.addState(new int[]{android.R.attr.state_focused}, new ColorDrawable(0x55FFFFFF));
        d.addState(new int[]{}, new ColorDrawable(Color.TRANSPARENT));
        return d;
    }

    private void styleCell(TextView t) {
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.WHITE);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setCompoundDrawablePadding(dp(8));
        t.setPadding(dp(8), dp(12), dp(8), dp(12));
    }

    private void bindCell(TextView t, AppEntry e, boolean fav) {
        Drawable ic;
        if (fav) {
            if (e.favIcon == null) e.favIcon = e.info.loadIcon(pm);
            ic = e.favIcon;
        } else {
            if (e.icon == null) e.icon = e.info.loadIcon(pm); // caricata solo quando serve
            ic = e.icon;
        }
        ic.setBounds(0, 0, iconSize, iconSize);
        t.setText(e.label);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, TEXT_SP[iconLevel]);
        t.setCompoundDrawables(null, ic, null, null);
    }

    /** Applica dimensione icone e ridisegna griglia e preferiti. */
    private void applySize() {
        iconSize = dp(ICON_DP[iconLevel]);
        grid.setColumnWidth(dp(COL_DP[iconLevel]));
        adapter.notifyDataSetChanged();
        buildFavRow();
    }

    private void buildFavRow() {
        favRow.removeAllViews();
        boolean empty = favApps.isEmpty();
        favScroll.setVisibility(empty ? View.GONE : View.VISIBLE);
        hint.setVisibility(empty ? View.VISIBLE : View.GONE);
        for (AppEntry e : favApps) {
            favRow.addView(makeFavView(e));
        }
    }

    private View makeFavView(final AppEntry e) {
        TextView t = new TextView(this);
        styleCell(t);
        t.setFocusable(true);
        t.setClickable(true);
        t.setBackground(focusBg());
        t.setTag(e);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                dp(COL_DP[iconLevel]), dp(CELL_DP[iconLevel]));
        lp.setMargins(dp(4), 0, dp(4), 0);
        t.setLayoutParams(lp);
        bindCell(t, e, true);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                launch(e);
            }
        });
        t.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showAppMenu(e, true);
                return true;
            }
        });
        return t;
    }

    private void focusFav(AppEntry e) {
        for (int i = 0; i < favRow.getChildCount(); i++) {
            View v = favRow.getChildAt(i);
            if (v.getTag() == e) {
                v.requestFocus();
                return;
            }
        }
    }

    // ---------------------------------------------------------------- azioni

    private void launch(AppEntry e) {
        try {
            startActivity(e.launch);
        } catch (Exception ex) {
            Toast.makeText(this, "Impossibile avviare " + e.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void openAppInfo(AppEntry e) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + e.pkg));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ex) {
            Toast.makeText(this, "Informazioni app non disponibili", Toast.LENGTH_SHORT).show();
        }
    }

    private void showAppMenu(final AppEntry e, final boolean fromFav) {
        final boolean isFav = favApps.contains(e);
        String[] labels = {
                isFav ? "Togli dai preferiti" : "Aggiungi ai preferiti",
                "Sposta prima",
                "Sposta dopo",
                "Nascondi",
                "Informazioni app (cache, disinstalla)"
        };
        new AlertDialog.Builder(this)
                .setTitle(e.label)
                .setItems(labels, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                toggleFavorite(e, isFav, fromFav);
                                break;
                            case 1:
                            case 2:
                                int delta = which == 1 ? -1 : 1;
                                if (fromFav) moveInFav(e, delta);
                                else moveInGrid(e, delta);
                                showAppMenu(e, fromFav); // resta aperto per spostare piu' volte
                                break;
                            case 3:
                                hideApp(e);
                                break;
                            case 4:
                                openAppInfo(e);
                                break;
                            default:
                                break;
                        }
                    }
                })
                .setNegativeButton("Chiudi", null)
                .show();
    }

    private void toggleFavorite(AppEntry e, boolean isFav, boolean fromFav) {
        List<String> fav = getList(KEY_FAV);
        if (isFav) {
            fav.remove(e.pkg);
        } else if (!fav.contains(e.pkg)) {
            fav.add(e.pkg);
        }
        putList(KEY_FAV, fav);
        rebuildLists();
        if (fromFav) grid.requestFocus();
    }

    private void hideApp(AppEntry e) {
        List<String> hidden = getList(KEY_HIDDEN);
        if (!hidden.contains(e.pkg)) hidden.add(e.pkg);
        putList(KEY_HIDDEN, hidden);
        rebuildLists();
        grid.requestFocus();
        Toast.makeText(this, e.label + " nascosta. Ripristino: Impostazioni > App nascoste",
                Toast.LENGTH_LONG).show();
    }

    private void moveInGrid(AppEntry e, int delta) {
        int i = gridApps.indexOf(e);
        int j = i + delta;
        if (i < 0 || j < 0 || j >= gridApps.size()) return;
        Collections.swap(gridApps, i, j);
        List<String> order = new ArrayList<>();
        for (AppEntry a : gridApps) order.add(a.pkg);
        for (String p : getList(KEY_ORDER)) { // conserva la posizione delle app nascoste
            if (!order.contains(p)) order.add(p);
        }
        putList(KEY_ORDER, order);
        rebuildLists();
        grid.setSelection(j);
    }

    private void moveInFav(AppEntry e, int delta) {
        int i = favApps.indexOf(e);
        int j = i + delta;
        if (i < 0 || j < 0 || j >= favApps.size()) return;
        Collections.swap(favApps, i, j);
        List<String> fav = new ArrayList<>();
        for (AppEntry a : favApps) fav.add(a.pkg);
        for (String p : getList(KEY_FAV)) { // conserva le preferite non visibili
            if (!fav.contains(p)) fav.add(p);
        }
        putList(KEY_FAV, fav);
        rebuildLists();
        focusFav(e);
    }

    // ---------------------------------------------------------------- meteo (Open-Meteo)

    private static String httpGet(String urlStr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            if (c.getResponseCode() != 200) {
                throw new IOException("HTTP " + c.getResponseCode());
            }
            BufferedReader r = new BufferedReader(
                    new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private static String weatherIcon(int c) {
        if (c == 0) return "☀️";                          // sereno
        if (c == 1 || c == 2) return "⛅";                      // poco nuvoloso
        if (c == 3) return "☁️";                          // nuvoloso
        if (c == 45 || c == 48) return "🌫️";        // nebbia
        if (c >= 51 && c <= 57) return "🌦️";        // pioviggine
        if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) {
            return "🌧️";                            // pioggia
        }
        if ((c >= 71 && c <= 77) || c == 85 || c == 86) {
            return "❄️";                                  // neve
        }
        if (c >= 95) return "⛈️";                         // temporale
        return "☁️";
    }

    private static String weatherText(int c) {
        if (c == 0) return "Sereno";
        if (c == 1) return "Quasi sereno";
        if (c == 2) return "Poco nuvoloso";
        if (c == 3) return "Nuvoloso";
        if (c == 45 || c == 48) return "Nebbia";
        if (c >= 51 && c <= 57) return "Pioviggine";
        if (c == 66 || c == 67) return "Pioggia gelata";
        if (c >= 61 && c <= 65) return "Pioggia";
        if (c >= 71 && c <= 77) return "Neve";
        if (c >= 80 && c <= 82) return "Rovesci";
        if (c == 85 || c == 86) return "Rovesci di neve";
        if (c >= 95) return "Temporale";
        return "Variabile";
    }

    /** Mostra l'ultimo meteo salvato (subito, anche senza rete). */
    private void showWeather() {
        String city = prefs.getString(KEY_CITY, "");
        if (city.length() == 0) {
            wTemp.setText("Meteo");
            wInfo.setText("Imposta la città");
            return;
        }
        if (!prefs.contains(KEY_W_TEMP)) {
            wTemp.setText("…");
            wInfo.setText(city);
            return;
        }
        int code = prefs.getInt(KEY_W_CODE, 3);
        wTemp.setText(weatherIcon(code) + " " + prefs.getInt(KEY_W_TEMP, 0) + "°");
        String second = "min " + prefs.getInt(KEY_W_MIN, 0) + "° · max "
                + prefs.getInt(KEY_W_MAX, 0) + "°";
        long age = System.currentTimeMillis() - prefs.getLong(KEY_W_TIME, 0);
        if (age > WEATHER_STALE) second += " · non aggiornato";
        wInfo.setText(city + " · " + weatherText(code) + "\n" + second);
    }

    /** Scarica il meteo se i dati hanno piu' di 30 minuti (o se force). Non blocca l'interfaccia. */
    private void refreshWeather(boolean force) {
        final String lat = prefs.getString(KEY_LAT, null);
        final String lon = prefs.getString(KEY_LON, null);
        if (lat == null || lon == null || weatherLoading) return;
        long now = System.currentTimeMillis();
        if (!force) {
            if (now - prefs.getLong(KEY_W_TIME, 0) < WEATHER_MAX_AGE) return;
            if (now - lastWeatherTry < WEATHER_RETRY) return;
        }
        lastWeatherTry = now;
        weatherLoading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String url = "https://api.open-meteo.com/v1/forecast?latitude=" + lat
                            + "&longitude=" + lon
                            + "&current=temperature_2m,weather_code"
                            + "&daily=temperature_2m_max,temperature_2m_min"
                            + "&forecast_days=1&timezone=auto";
                    JSONObject j = new JSONObject(httpGet(url));
                    JSONObject cur = j.getJSONObject("current");
                    JSONObject daily = j.getJSONObject("daily");
                    prefs.edit()
                            .putInt(KEY_W_TEMP, (int) Math.round(cur.getDouble("temperature_2m")))
                            .putInt(KEY_W_CODE, cur.getInt("weather_code"))
                            .putInt(KEY_W_MAX, (int) Math.round(
                                    daily.getJSONArray("temperature_2m_max").getDouble(0)))
                            .putInt(KEY_W_MIN, (int) Math.round(
                                    daily.getJSONArray("temperature_2m_min").getDouble(0)))
                            .putLong(KEY_W_TIME, System.currentTimeMillis())
                            .apply();
                } catch (Exception ignored) {
                    // nessuna rete o risposta non valida: resta l'ultimo dato salvato
                }
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        weatherLoading = false;
                        showWeather();
                    }
                });
            }
        }).start();
    }

    private void showCityDialog() {
        final EditText in = new EditText(this);
        in.setSingleLine(true);
        in.setHint("Es. Roma");
        in.setText(prefs.getString(KEY_CITY, ""));
        LinearLayout box = new LinearLayout(this);
        box.setPadding(dp(24), dp(8), dp(24), 0);
        box.addView(in, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        new AlertDialog.Builder(this)
                .setTitle("Città per il meteo")
                .setView(box)
                .setPositiveButton("Salva", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        lookupCity(in.getText().toString().trim());
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    /** Cerca la citta' (coordinate) con il servizio di ricerca di Open-Meteo e la salva. */
    private void lookupCity(final String name) {
        if (name.length() == 0) return;
        Toast.makeText(this, "Cerco " + name + "…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                String foundName = null;
                String foundLat = null;
                String foundLon = null;
                try {
                    String url = "https://geocoding-api.open-meteo.com/v1/search?name="
                            + URLEncoder.encode(name, "UTF-8")
                            + "&count=1&language=it&format=json";
                    JSONObject j = new JSONObject(httpGet(url));
                    JSONArray res = j.optJSONArray("results");
                    if (res != null && res.length() > 0) {
                        JSONObject r = res.getJSONObject(0);
                        foundName = r.getString("name");
                        foundLat = Double.toString(r.getDouble("latitude"));
                        foundLon = Double.toString(r.getDouble("longitude"));
                    }
                } catch (Exception ignored) {
                    // lasciamo foundName a null: verra' mostrato l'errore
                }
                final String fn = foundName;
                final String flat = foundLat;
                final String flon = foundLon;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (fn == null) {
                            Toast.makeText(MainActivity.this,
                                    "Città non trovata o nessuna connessione",
                                    Toast.LENGTH_LONG).show();
                            return;
                        }
                        prefs.edit()
                                .putString(KEY_CITY, fn)
                                .putString(KEY_LAT, flat)
                                .putString(KEY_LON, flon)
                                .remove(KEY_W_TEMP).remove(KEY_W_CODE)
                                .remove(KEY_W_MIN).remove(KEY_W_MAX).remove(KEY_W_TIME)
                                .apply();
                        showWeather();
                        refreshWeather(true);
                    }
                });
            }
        }).start();
    }

    // ---------------------------------------------------------------- impostazioni

    private int countHidden() {
        Set<String> hidden = new HashSet<>(getList(KEY_HIDDEN));
        int n = 0;
        for (AppEntry e : all) {
            if (hidden.contains(e.pkg)) n++;
        }
        return n;
    }

    private void showSettings() {
        String[] items = {
                "Dimensione icone: " + ICON_NAMES[iconLevel],
                "Sfondo: " + BG_NAMES[bgIndex],
                "Meteo: " + (prefs.getString(KEY_CITY, "").length() > 0
                        ? prefs.getString(KEY_CITY, "") : "imposta la città"),
                "App nascoste (" + countHidden() + ")",
                "Ripristina ordine alfabetico"
        };
        new AlertDialog.Builder(this)
                .setTitle("Impostazioni")
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                pickIconSize();
                                break;
                            case 1:
                                pickBackground();
                                break;
                            case 2:
                                showCityDialog();
                                break;
                            case 3:
                                showHiddenApps();
                                break;
                            case 4:
                                prefs.edit().remove(KEY_ORDER).apply();
                                rebuildLists();
                                Toast.makeText(MainActivity.this, "Ordine ripristinato",
                                        Toast.LENGTH_SHORT).show();
                                break;
                            default:
                                break;
                        }
                    }
                })
                .setNegativeButton("Chiudi", null)
                .show();
    }

    private void pickIconSize() {
        new AlertDialog.Builder(this)
                .setTitle("Dimensione icone")
                .setSingleChoiceItems(ICON_NAMES, iconLevel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        iconLevel = which;
                        prefs.edit().putInt(KEY_ICON, which).apply();
                        applySize();
                        dialog.dismiss();
                    }
                })
                .show();
    }

    private void pickBackground() {
        new AlertDialog.Builder(this)
                .setTitle("Sfondo")
                .setSingleChoiceItems(BG_NAMES, bgIndex, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        bgIndex = which;
                        prefs.edit().putInt(KEY_BG, which).apply();
                        root.setBackgroundColor(BG_COLORS[which]);
                        dialog.dismiss();
                    }
                })
                .show();
    }

    private void showHiddenApps() {
        Set<String> hidden = new HashSet<>(getList(KEY_HIDDEN));
        final List<AppEntry> list = new ArrayList<>();
        for (AppEntry e : all) {
            if (hidden.contains(e.pkg)) list.add(e);
        }
        if (list.isEmpty()) {
            Toast.makeText(this, "Nessuna app nascosta", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[list.size()];
        final boolean[] checked = new boolean[list.size()];
        for (int i = 0; i < names.length; i++) {
            names[i] = list.get(i).label;
            checked[i] = true;
        }
        new AlertDialog.Builder(this)
                .setTitle("App nascoste (togli la spunta per mostrarle)")
                .setMultiChoiceItems(names, checked, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        checked[which] = isChecked;
                    }
                })
                .setPositiveButton("Fatto", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        List<String> h = getList(KEY_HIDDEN);
                        for (int i = 0; i < list.size(); i++) {
                            if (!checked[i]) h.remove(list.get(i).pkg);
                        }
                        putList(KEY_HIDDEN, h);
                        rebuildLists();
                    }
                })
                .setNegativeButton("Annulla", null)
                .show();
    }

    // ---------------------------------------------------------------- elenco app

    /** Ricarica l'elenco in un thread separato per non bloccare l'interfaccia. */
    private void reload() {
        if (loading) {
            reloadPending = true;
            return;
        }
        loading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final List<AppEntry> result = queryApps();
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        all.clear();
                        all.addAll(result);
                        rebuildLists();
                        loading = false;
                        if (reloadPending) {
                            reloadPending = false;
                            reload();
                        }
                    }
                });
            }
        }).start();
    }

    private List<AppEntry> queryApps() {
        List<AppEntry> result = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        seen.add(getPackageName()); // escludi il launcher stesso

        // Prima le app per TV, poi quelle "normali" non ancora viste
        addApps(result, seen, Intent.CATEGORY_LEANBACK_LAUNCHER);
        addApps(result, seen, Intent.CATEGORY_LAUNCHER);

        Collections.sort(result, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return String.CASE_INSENSITIVE_ORDER.compare(a.label, b.label);
            }
        });
        return result;
    }

    private void addApps(List<AppEntry> out, Set<String> seen, String category) {
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(category);
        List<ResolveInfo> list = pm.queryIntentActivities(query, 0);
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (!seen.add(pkg)) continue;
            Intent launch = new Intent(Intent.ACTION_MAIN)
                    .addCategory(category)
                    .setClassName(pkg, ri.activityInfo.name)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                            | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            out.add(new AppEntry(String.valueOf(ri.loadLabel(pm)), pkg, launch, ri));
        }
    }

    // ---------------------------------------------------------------- adapter

    private final class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return gridApps.size();
        }

        @Override
        public Object getItem(int position) {
            return gridApps.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            TextView t = (TextView) convertView;
            if (t == null) {
                t = new TextView(MainActivity.this);
                styleCell(t);
            }
            int h = dp(CELL_DP[iconLevel]);
            ViewGroup.LayoutParams lp = t.getLayoutParams();
            if (lp == null || lp.height != h) {
                t.setLayoutParams(new AbsListView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, h));
            }
            bindCell(t, gridApps.get(position), false);
            return t;
        }
    }
}
